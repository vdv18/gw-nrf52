# Simple hardware abstraction layer

The simple hardware abstraction layer is a module that provides simple drivers for
the buttons and LEDs on development kits. It is used in the various mesh example
projects.

