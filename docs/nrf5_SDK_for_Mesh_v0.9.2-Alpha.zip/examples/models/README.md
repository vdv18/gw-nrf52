# Example models

This folder contains all example models:

* @subpage md_examples_models_simple_on_off_README "Simple OnOff model" - An example
  of a custom model that implements a simple OnOff model.